package vip.bot;

import java.util.List;
import java.util.logging.Level;

import cz.cuni.amis.pogamut.base.agent.navigation.IPathFuture;
import cz.cuni.amis.pogamut.base.communication.worldview.listener.annotation.EventListener;
import cz.cuni.amis.pogamut.base3d.worldview.object.ILocated;
import cz.cuni.amis.pogamut.base3d.worldview.object.Location;
import cz.cuni.amis.pogamut.ut2004.agent.module.utils.TabooSet;
import cz.cuni.amis.pogamut.ut2004.agent.navigation.NavigationState;
import cz.cuni.amis.pogamut.ut2004.bot.impl.UT2004Bot;
import cz.cuni.amis.pogamut.ut2004.communication.messages.gbcommands.Initialize;
import cz.cuni.amis.pogamut.ut2004.communication.messages.gbinfomessages.BotKilled;
import cz.cuni.amis.pogamut.ut2004.communication.messages.gbinfomessages.ConfigChange;
import cz.cuni.amis.pogamut.ut2004.communication.messages.gbinfomessages.GameInfo;
import cz.cuni.amis.pogamut.ut2004.communication.messages.gbinfomessages.InitedMessage;
import cz.cuni.amis.pogamut.ut2004.communication.messages.gbinfomessages.Item;
import cz.cuni.amis.pogamut.ut2004.utils.UT2004BotRunner;
import cz.cuni.amis.pogamut.ut2004.vip.bot.UT2004BotVIPController;
import cz.cuni.amis.pogamut.ut2004.vip.protocol.CSBotTeam;
import cz.cuni.amis.pogamut.ut2004.vip.protocol.messages.CSRoundStart;
import cz.cuni.amis.utils.exception.PogamutException;
import cz.cuni.amis.utils.flag.FlagListener;
import vip.tc.CommObjectUpdates;
import vip.tc.CommUser;
import vip.tc.msgs.TCRunningTo;

public class CounterBot extends UT2004BotVIPController<UT2004Bot> {

	private static int INSTANCE = 0;
	
	/**
	 * Skins that are used for counter-terrorists bot.
	 */
	private static String[] SKINS = new String[]{ "Bot.BotA", "Bot.BotB", "Bot.BotC", "Bot.BotD" };    
	//private static String[] SKINS = new String[]{ "neo", "neo", "neo", "neo" };
	
	/**
	 * Speed of the VIP bot.
	 */
	public static final double VIPBOT_SPEED = 0.6;
	
	/**
	 * Normal speed of the bot (i.e., one that the bot initially has). 
	 */
	public static final double NORMAL_SPEED = 1.0;

	private int logicIteration = 0;
	
	/**
	 * Used to taboo items we were stuck going for or we have picked up recently
	 */
	public TabooSet<Item> tabooItems;

	/** My current speed. */
	public double speed = 1;

	/** Sharing states of objects within the game with other team mates. */
	public CommObjectUpdates<CounterBot> commObjects;

	/** User communication. */
	public CommUser<CounterBot> commUser;
	
	/** Location VIP is currently navigating to. */
	public Location vipRunningTo;
	
	/** 
	 * Current item our bot is currently going for
	 * TODO: needs to be filled in properly
	 */
	public Item targetItem = null;
	
    /**
     * Initialize command of the bot, called during initial handshake, init can
     * set things like name of bot, its skin, skill, team ect.
     *
     * @see Initialize
     * @return
     */
    @Override
    public Initialize getInitializeCommand() {
        return new Initialize().setName("Neo-" + (++INSTANCE)).setDesiredSkill(6).setTeam(CSBotTeam.COUNTER_TERRORIST.ut2004Team).setSkin(SKINS[INSTANCE-1]);
    }

    @Override
    public void botInitialized(GameInfo gameInfo, ConfigChange currentConfig, InitedMessage init) {
        super.botInitialized(gameInfo, currentConfig, init);
        log.setLevel(Level.INFO);
        bot.getLogger().getCategory("Yylex").setLevel(Level.OFF);
        
        // INITIALIZE CUSTOM MODULES
 		tabooItems = new TabooSet<Item>(bot);

 		this.getNavigation().addStrongNavigationListener(
 				new FlagListener<NavigationState>() {
 					@Override
 					public void flagChanged(NavigationState changedValue) {
 						switch (changedValue) {
 						case PATH_COMPUTATION_FAILED:
 						case STUCK:
 							if (targetItem != null)
 								tabooItems.add(targetItem, 30);
 							break;
 						case TARGET_REACHED:
 							if (targetItem != null)
 								tabooItems.add(targetItem, 5);
 							break;
 						}
 					}
 				});

 		commObjects = new CommObjectUpdates<CounterBot>(this);
 		commUser = new CommUser<CounterBot>(this);

     	// this.getWeaponPrefs()
     	// .addGeneralPref(ItemType.LIGHTNING_GUN, true)
     	// .addGeneralPref(ItemType.SHOCK_RIFLE, true)
     	// .addGeneralPref(ItemType.FLAK_CANNON, true)
     	// .addGeneralPref(ItemType.MINIGUN, true)
     	// .addGeneralPref(ItemType.LINK_GUN, true)
     	// .addGeneralPref(ItemType.ASSAULT_RIFLE, true);
    }
    
    /**
	 * VIP Game Restart!
	 * @param event
	 */
	@EventListener(eventClass=CSRoundStart.class)
	public void roundStart(CSRoundStart event) {
		vipRunningTo = null;
	}
	
	@EventListener(eventClass=TCRunningTo.class)
	public void playerRunningTo(TCRunningTo event) {
		if (event.id.equals(getVip().getVIPId())) {
			vipRunningTo = event.location;
		}
	}
	
	/**
	 * Changes the speed of the bot to match the speed of VIP
	 */
	public void setVIPSpeed() {
		getConfig().setSpeedMultiplier(VIPBOT_SPEED);
        speed = VIPBOT_SPEED;
	}
	
	/**
	 * Changes the speed of the bot back to normal.
	 */
	public void setNormalSpeed() {
		getConfig().setSpeedMultiplier(NORMAL_SPEED);
        speed = NORMAL_SPEED;
	}
	
	public boolean isVIPSpeed() {
		return Math.abs(speed - VIPBOT_SPEED) < 0.001;
	}
	
	public boolean isNormalSpeed() {
		return Math.abs(speed - NORMAL_SPEED) < 0.001;
	}
	
	public void dodgeLeft(boolean doubleDodge) {
		if (info.getVelocity().isZero(0.1)) return;
		Location inFront = info.getLocation().add(info.getVelocity().asLocation().getNormalized().scale(100));
		move.dodgeLeft(inFront, doubleDodge);
	}
	
	public void dodgeRight(boolean doubleDodge) {
		if (info.getVelocity().isZero(0.1)) return;
		Location inFront = info.getLocation().add(info.getVelocity().asLocation().getNormalized().scale(100));
		move.dodgeRight(inFront, doubleDodge);
	}	
    
    @Override
    public void logic() {
    	log.info("-----/// LOGIC ITERATION " + (logicIteration++) + "///-----");
    	
    	// COMMUNICATION UPDATE
    	commObjects.update();
		commUser.update();
    	
		// WAIT FOR VIP ROUND
    	if (!vip.isRoundRunning()) {
    		log.info("ROUND NOT RUNNING...");
    	}
    	
    	// TODO: CODE YOUR BEHAVIOR HERE!
    	
    	log.info("VIP Running to: " + vipRunningTo);
    	
    }
    
    /**
	 * Returns a navmesh path distance between two points within the environment.
	 * @param from
	 * @param to
	 * @return
	 */
	public double getPathDistance(Location from, Location to) {
		IPathFuture<ILocated> future = getNavMeshModule().getAStarPathPlanner().computePath(from, to);
		List<ILocated> pathPoints = future.get();		
		if (pathPoints != null && pathPoints.size() > 1) {
			double distance = 0;
			Location last = pathPoints.get(0).getLocation();
			for (int i = 1; i < pathPoints.size(); ++i) {
				distance += last.getDistance(pathPoints.get(i).getLocation());
				last = pathPoints.get(i).getLocation();
			}
			return distance;
		} else {
			return fwMap.getDistance(navPoints.getNearestNavPoint(from), navPoints.getNearestNavPoint(to));
		}
	}

    @Override
    public void botKilled(BotKilled event) {
    }

    public static void main(String[] args) throws PogamutException {
        new UT2004BotRunner(CounterBot.class, "CTBot").setMain(true).setLogLevel(Level.WARNING).startAgents(1);
    }
    
}
